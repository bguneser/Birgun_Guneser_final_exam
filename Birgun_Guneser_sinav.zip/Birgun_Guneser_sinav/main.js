

function showInfo() {

	var name = document.getElementById("name").value;
	var surname = document.getElementById("surname").value;
	var email = document.getElementById("email").value;

	alert( "name: " +name + "surname: " +surname + "email: "+email );

	$('#element').hide();

}


