var name = document.getElementById(name).innerHTML.name;

alert(name)